package fa.training.services;

import fa.training.entities.Order;
import fa.training.utils.Validator;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class OrderService {

    private Scanner sc = new Scanner(System.in);

    public Order createOrder() {

        String number;

        while (true) {
            System.out.print("Enter order number: ");
            number = sc.nextLine();

            if (Validator.isValidOrderNumber(number)) {
                break;
            }

            System.out.println("Invalid order number!");
        }

        System.out.print("Enter date (dd/MM/yyyy): ");
        String dateStr = sc.nextLine();

        Date date = null;

        try {
            date = new SimpleDateFormat("dd/MM/yyyy")
                    .parse(dateStr);
        } catch (ParseException e) {
            date = new Date();
        }

        return new Order(number, date);
    }
}