package fa.training.services;

import fa.training.entities.Customer;
import fa.training.entities.Order;
import fa.training.utils.Constants;
import fa.training.utils.Validator;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class CustomerService {

    private Scanner sc = new Scanner(System.in);

    public List<Customer> createCustomer() {

        List<Customer> customers = new ArrayList<>();

        while (true) {

            Customer customer = new Customer();

            System.out.print("Enter name: ");
            customer.setName(sc.nextLine());

            String phone;

            while (true) {

                System.out.print("Enter phone: ");
                phone = sc.nextLine();

                if (Validator.isValidPhone(phone)) {
                    break;
                }

                System.out.println("Invalid phone!");
            }

            customer.setPhone(phone);

            System.out.print("Enter address: ");
            customer.setAddress(sc.nextLine());

            List<Order> orders = new ArrayList<>();

            OrderService orderService = new OrderService();

            while (true) {

                Order order = orderService.createOrder();
                orders.add(order);

                System.out.print("Continue order? (y/n): ");
                String choose = sc.nextLine();

                if (choose.equalsIgnoreCase("n")) {
                    break;
                }
            }

            customer.setOrders(orders);

            customers.add(customer);

            System.out.print("Continue customer? (y/n): ");
            String choose = sc.nextLine();

            if (choose.equalsIgnoreCase("n")) {
                break;
            }
        }

        return customers;
    }

    public String save(List<Customer> customers) {

        try (ObjectOutputStream oos =
                     new ObjectOutputStream(
                             new FileOutputStream(Constants.FILE_NAME))) {

            oos.writeObject(customers);

            return "Save successfully";

        } catch (Exception e) {
            return "Save failed";
        }
    }

    public List<Customer> findAll() {

        try (ObjectInputStream ois =
                     new ObjectInputStream(
                             new FileInputStream(Constants.FILE_NAME))) {

            return (List<Customer>) ois.readObject();

        } catch (Exception e) {

            return new ArrayList<>();
        }
    }

    public void display(List<Customer> customers) {

        System.out.println("------LIST OF CUSTOMER------");

        for (Customer c : customers) {
            System.out.println(c);
        }
    }

    public List<Customer> search(String phone) {

        List<Customer> result = new ArrayList<>();

        List<Customer> customers = findAll();

        for (Customer c : customers) {

            if (c.getPhone().contains(phone)) {
                result.add(c);
            }
        }

        return result;
    }

    public boolean remove(String phone) {

        List<Customer> customers = findAll();

        boolean removed =
                customers.removeIf(c ->
                        c.getPhone().equals(phone));

        if (removed) {
            save(customers);
        }

        return removed;
    }
}