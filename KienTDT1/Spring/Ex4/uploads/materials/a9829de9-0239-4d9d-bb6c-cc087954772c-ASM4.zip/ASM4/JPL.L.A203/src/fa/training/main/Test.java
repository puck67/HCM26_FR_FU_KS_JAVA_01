package fa.training.main;

import fa.training.entities.Customer;
import fa.training.services.CustomerService;

import java.util.List;
import java.util.Scanner;

public class Test {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        CustomerService service = new CustomerService();

        while (true) {

            System.out.println("\nChoose function:");
            System.out.println("1. Add new customer");
            System.out.println("2. Show all customer");
            System.out.println("3. Search customer");
            System.out.println("4. Remove customer");
            System.out.println("5. Exit");

            System.out.print("Choose: ");

            int choice = Integer.parseInt(sc.nextLine());

            switch (choice) {

                case 1:

                    List<Customer> customers =
                            service.createCustomer();

                    System.out.println(
                            service.save(customers));

                    break;

                case 2:

                    service.display(service.findAll());

                    break;

                case 3:

                    System.out.print("Enter phone: ");

                    String phoneSearch = sc.nextLine();

                    List<Customer> result =
                            service.search(phoneSearch);

                    service.display(result);

                    break;

                case 4:

                    System.out.print("Enter phone remove: ");

                    String phoneRemove = sc.nextLine();

                    boolean removed =
                            service.remove(phoneRemove);

                    if (removed) {
                        System.out.println("Removed!");
                    } else {
                        System.out.println("Not found!");
                    }

                    break;

                case 5:

                    System.exit(0);
            }
        }
    }
}