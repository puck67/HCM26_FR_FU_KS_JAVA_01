package fa.training.utils;

public class Validator {

    // phone: 10 số
    public static boolean isValidPhone(String phone) {
        return phone.matches("\\d{10}");
    }

    // order number: 10 ký tự số
    public static boolean isValidOrderNumber(String number) {
        return number.matches("\\d{10}");
    }
}