package fa.training.entities;

public class Helicopter extends Airplane {

    private double range;

    public Helicopter() {
    }

    public Helicopter(String id, String model, double cruiseSpeed,
                      double emptyWeight, double maxTakeoffWeight, double range) {
        super(id, model, cruiseSpeed, emptyWeight, maxTakeoffWeight);
        this.range = range;
    }

    @Override
    public FlyMethod flyMethod() {
        return FlyMethod.ROTATED_WING;
    }

    public double getRange() {
        return range;
    }

    public void setRange(double range) {
        this.range = range;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append("Helicopter{id='").append(id)
                .append("', model='").append(model)
                .append("', cruiseSpeed=").append(cruiseSpeed)
                .append(", emptyWeight=").append(emptyWeight)
                .append(", maxTakeoffWeight=").append(maxTakeoffWeight)
                .append(", range=").append(range)
                .append('}');
        return sb.toString();
    }
}
