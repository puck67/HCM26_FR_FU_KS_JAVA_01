package fa.training.services;

import fa.training.entities.Airport;
import fa.training.entities.Helicopter;
import fa.training.utils.DataStore;
import fa.training.utils.Validation;

import java.util.Map;

public class HelicopterService {

    private DataStore store = DataStore.getInstance();

    public void createHelicopter(String id,
                                 String model,
                                 double cruiseSpeed,
                                 double emptyWeight,
                                 double maxTakeoff,
                                 double range) {

        if (!Validation.checkHelicopterID(id)) {
            System.out.println("Invalid helicopter id!");
            return;
        }

        if (!Validation.isHelicopterIdUnique(id)) {
            System.out.println("Helicopter id exists!");
            return;
        }

        Helicopter helicopter =
                new Helicopter(
                        id,
                        model,
                        cruiseSpeed,
                        emptyWeight,
                        maxTakeoff,
                        range
                );

        if (!Validation.checkHelicopterWeight(helicopter)) {
            System.out.println("Invalid weight!");
            return;
        }

        store.getHelicopters().put(id, helicopter);

        System.out.println("Create helicopter success!");
    }

    public void addToAirport(String airportId,
                             String helicopterId) {

        Airport airport =
                store.getAirports().get(airportId);

        if (airport == null) {
            System.out.println("Airport not found!");
            return;
        }

        Helicopter helicopter =
                store.getHelicopters().get(helicopterId);

        if (helicopter == null) {
            System.out.println("Helicopter not found!");
            return;
        }

        airport.getHelicopterIDs()
                .add(helicopterId);

        System.out.println("Add helicopter success!");
    }

    public void displayAllHelicopter() {

        Map<String, Helicopter> helicopters =
                store.getHelicopters();

        if (helicopters.isEmpty()) {
            System.out.println("No helicopter found!");
            return;
        }

        System.out.println("----- HELICOPTER LIST -----");

        for (Helicopter helicopter
                : helicopters.values()) {

            System.out.println(helicopter);
        }
    }
}