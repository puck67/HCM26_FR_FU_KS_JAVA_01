package fa.training.utils;

import fa.training.entities.Airport;
import fa.training.entities.Helicopter;
import fa.training.entities.PlaneType;

public final class Validation {

    private static final int ID_LENGTH = 7;
    private static final int MODEL_MAX_LENGTH = 40;

    private Validation() {
    }

    public static boolean checkAirportID(String id) {
        return id != null && id.length() == ID_LENGTH
                && id.charAt(0) == 'A' && id.charAt(1) == 'P'
                && isAllDigits(id, 2, ID_LENGTH);
    }

    public static boolean checkFixedWingID(String id) {
        return id != null && id.length() == ID_LENGTH
                && id.charAt(0) == 'F' && id.charAt(1) == 'W'
                && isAllDigits(id, 2, ID_LENGTH);
    }

    public static boolean checkHelicopterID(String id) {
        return id != null && id.length() == ID_LENGTH
                && id.charAt(0) == 'R' && id.charAt(1) == 'W'
                && isAllDigits(id, 2, ID_LENGTH);
    }

    public static boolean checkModel(String model) {
        if (model == null) {
            return false;
        }
        int start = 0;
        int end = model.length() - 1;
        while (start <= end && Character.isWhitespace(model.charAt(start))) {
            start++;
        }
        while (end >= start && Character.isWhitespace(model.charAt(end))) {
            end--;
        }
        int length = end - start + 1;
        return length > 0 && length <= MODEL_MAX_LENGTH;
    }

    public static String trimModel(String model) {
        if (model == null) {
            return null;
        }
        int start = 0;
        int end = model.length() - 1;
        while (start <= end && Character.isWhitespace(model.charAt(start))) {
            start++;
        }
        while (end >= start && Character.isWhitespace(model.charAt(end))) {
            end--;
        }
        return model.substring(start, end + 1);
    }

    public static boolean checkPlaneType(PlaneType type) {
        return type != null;
    }

    public static boolean checkHelicopterWeight(Helicopter helicopter) {
        return helicopter.getMaxTakeoffWeight()
                <= 1.5 * helicopter.getEmptyWeight();
    }

    public static boolean isAirportIdUnique(String id) {
        return !DataStore.getInstance().getAirports().containsKey(id);
    }

    public static boolean isFixedWingIdUnique(String id) {
        return !DataStore.getInstance().getFixedWings().containsKey(id);
    }

    public static boolean isHelicopterIdUnique(String id) {
        return !DataStore.getInstance().getHelicopters().containsKey(id);
    }

    public static Airport findAirportByFixedWing(String fixedWingId) {
        for (Airport airport : DataStore.getInstance().getAirports().values()) {
            if (airport.getFixedWingIDs().contains(fixedWingId)) {
                return airport;
            }
        }
        return null;
    }

    public static Airport findAirportByHelicopter(String helicopterId) {
        for (Airport airport : DataStore.getInstance().getAirports().values()) {
            if (airport.getHelicopterIDs().contains(helicopterId)) {
                return airport;
            }
        }
        return null;
    }

    private static boolean isAllDigits(String value, int from, int to) {
        if (value == null) {
            return false;
        }
        for (int i = from; i < to; i++) {
            if (!Character.isDigit(value.charAt(i))) {
                return false;
            }
        }
        return true;
    }
}
