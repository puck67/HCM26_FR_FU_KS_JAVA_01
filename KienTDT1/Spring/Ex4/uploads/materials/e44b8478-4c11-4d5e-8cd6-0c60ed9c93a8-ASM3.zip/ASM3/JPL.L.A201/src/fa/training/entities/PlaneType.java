package fa.training.entities;

public enum PlaneType {
    CAG(1), LGR(2), PRV(3);

    private final int code;

    PlaneType(int code) {
        this.code = code;
    }

    public int getCode() {
        return code;
    }

    public static PlaneType fromCode(int code) {
        for (PlaneType type : values()) {
            if (type.code == code) {
                return type;
            }
        }
        return null;
    }
}
