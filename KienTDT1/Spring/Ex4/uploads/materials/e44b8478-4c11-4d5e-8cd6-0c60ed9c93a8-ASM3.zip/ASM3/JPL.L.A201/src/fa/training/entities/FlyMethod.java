package fa.training.entities;

public enum FlyMethod {
    FIXED_WING('F'),
    ROTATED_WING('R');

    private final char code;

    FlyMethod(char code) {
        this.code = code;
    }

    public char getCode() {
        return code;
    }
}
