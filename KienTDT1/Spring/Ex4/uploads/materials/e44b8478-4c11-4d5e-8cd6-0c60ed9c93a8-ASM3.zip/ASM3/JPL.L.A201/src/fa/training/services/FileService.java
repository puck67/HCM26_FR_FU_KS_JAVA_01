package fa.training.services;

import fa.training.entities.Airport;
import fa.training.entities.FixedWing;
import fa.training.entities.Helicopter;
import fa.training.utils.DataStore;
import fa.training.entities.PlaneType;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class FileService {

    private static final char SEPARATOR = '|';
    private static final File DATA_FILE = new File("data", "airport_data.txt");

    public File getDataFile() {
        return DATA_FILE;
    }

    public boolean saveToFile() {
        File parent = DATA_FILE.getParentFile();
        if (parent != null && !parent.exists() && !parent.mkdirs()) {
            System.err.println("Error: cannot create data directory.");
            return false;
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(DATA_FILE))) {
            DataStore store = DataStore.getInstance();

            for (FixedWing fw : store.getFixedWings().values()) {
                writer.write(buildFixedWingLine(fw));
                writer.newLine();
            }

            for (Helicopter heli : store.getHelicopters().values()) {
                writer.write(buildHelicopterLine(heli));
                writer.newLine();
            }

            for (Airport airport : store.getAirports().values()) {
                writer.write(buildAirportLine(airport));
                writer.newLine();
            }

            return true;
        } catch (IOException e) {
            System.err.println("Error saving data.");
            return false;
        }
    }

    public boolean loadFromFile() {
        if (!DATA_FILE.exists()) {
            return true;
        }

        DataStore store = DataStore.getInstance();
        store.clear();

        List<String[]> airportLines = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(DATA_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (isSkippableLine(line)) {
                    continue;
                }

                String[] parts = splitLine(line);
                if (parts.length < 2) {
                    continue;
                }

                if (isType(parts[0], 'F', 'I', 'X', 'E', 'D', 'W', 'I', 'N', 'G')
                        && parts.length >= 8) {
                    PlaneType type = PlaneType.fromCode(Integer.parseInt(parts[3]));
                    FixedWing fw = new FixedWing(
                            parts[1], parts[2],
                            Double.parseDouble(parts[4]),
                            Double.parseDouble(parts[5]),
                            Double.parseDouble(parts[6]),
                            type,
                            Double.parseDouble(parts[7]));
                    store.getFixedWings().put(fw.getId(), fw);
                } else if (isType(parts[0], 'H', 'E', 'L', 'I', 'C', 'O', 'P', 'T', 'E', 'R')
                        && parts.length >= 7) {
                    Helicopter heli = new Helicopter(
                            parts[1], parts[2],
                            Double.parseDouble(parts[3]),
                            Double.parseDouble(parts[4]),
                            Double.parseDouble(parts[5]),
                            Double.parseDouble(parts[6]));
                    store.getHelicopters().put(heli.getId(), heli);
                } else if (isType(parts[0], 'A', 'I', 'R', 'P', 'O', 'R', 'T')
                        && parts.length >= 7) {
                    airportLines.add(parts);
                }
            }

            for (String[] parts : airportLines) {
                Airport airport = new Airport(
                        parts[1], parts[2],
                        Double.parseDouble(parts[3]),
                        Integer.parseInt(parts[4]),
                        Integer.parseInt(parts[5]));
                airport.getFixedWingIDs().addAll(parseIds(parts[6]));
                airport.getHelicopterIDs().addAll(parseIds(parts[7]));
                store.getAirports().put(airport.getId(), airport);
            }

            return true;
        } catch (IOException | NumberFormatException e) {
            System.err.println("Error loading data.");
            store.clear();
            return false;
        }
    }

    private String buildFixedWingLine(FixedWing fw) {
        StringBuilder sb = new StringBuilder(96);
        sb.append("FIXEDWING").append(SEPARATOR)
                .append(fw.getId()).append(SEPARATOR)
                .append(fw.getModel()).append(SEPARATOR)
                .append(fw.getPlaneType().getCode()).append(SEPARATOR)
                .append(fw.getCruiseSpeed()).append(SEPARATOR)
                .append(fw.getEmptyWeight()).append(SEPARATOR)
                .append(fw.getMaxTakeoffWeight()).append(SEPARATOR)
                .append(fw.getMinNeededRunwaySize());
        return sb.toString();
    }

    private String buildHelicopterLine(Helicopter heli) {
        StringBuilder sb = new StringBuilder(96);
        sb.append("HELICOPTER").append(SEPARATOR)
                .append(heli.getId()).append(SEPARATOR)
                .append(heli.getModel()).append(SEPARATOR)
                .append(heli.getCruiseSpeed()).append(SEPARATOR)
                .append(heli.getEmptyWeight()).append(SEPARATOR)
                .append(heli.getMaxTakeoffWeight()).append(SEPARATOR)
                .append(heli.getRange());
        return sb.toString();
    }

    private String buildAirportLine(Airport airport) {
        StringBuilder sb = new StringBuilder(128);
        sb.append("AIRPORT").append(SEPARATOR)
                .append(airport.getId()).append(SEPARATOR)
                .append(airport.getName()).append(SEPARATOR)
                .append(airport.getRunwaySize()).append(SEPARATOR)
                .append(airport.getMaxFixedWingParkingPlace()).append(SEPARATOR)
                .append(airport.getMaxRotatedWingParkingPlace()).append(SEPARATOR)
                .append(joinIds(airport.getFixedWingIDs())).append(SEPARATOR)
                .append(joinIds(airport.getHelicopterIDs()));
        return sb.toString();
    }

    private boolean isSkippableLine(String line) {
        if (line == null || line.length() == 0) {
            return true;
        }
        return line.charAt(0) == '#';
    }

    private String[] splitLine(String line) {
        List<String> parts = new ArrayList<>();
        StringBuilder current = new StringBuilder();
        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);
            if (c == SEPARATOR) {
                parts.add(current.toString());
                current.setLength(0);
            } else {
                current.append(c);
            }
        }
        parts.add(current.toString());
        return parts.toArray(new String[0]);
    }

    private boolean isType(String value, char... expected) {
        if (value == null || value.length() != expected.length) {
            return false;
        }
        for (int i = 0; i < expected.length; i++) {
            if (Character.toUpperCase(value.charAt(i)) != expected[i]) {
                return false;
            }
        }
        return true;
    }

    private String joinIds(List<String> ids) {
        if (ids == null || ids.isEmpty()) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < ids.size(); i++) {
            if (i > 0) {
                sb.append(',');
            }
            sb.append(ids.get(i));
        }
        return sb.toString();
    }

    private List<String> parseIds(String value) {
        List<String> ids = new ArrayList<>();
        if (value == null || value.length() == 0) {
            return ids;
        }
        StringBuilder current = new StringBuilder();
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            if (c == ',') {
                addId(ids, current);
            } else if (!Character.isWhitespace(c)) {
                current.append(c);
            }
        }
        addId(ids, current);
        return ids;
    }

    private void addId(List<String> ids, StringBuilder current) {
        if (current.length() > 0) {
            ids.add(current.toString());
            current.setLength(0);
        }
    }
}
