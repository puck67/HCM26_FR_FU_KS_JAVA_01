package fa.training.utils;

import fa.training.entities.Airport;
import fa.training.entities.FixedWing;
import fa.training.entities.Helicopter;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class DataStore {

    private static final DataStore INSTANCE = new DataStore();

    private final Map<String, Airport> airports = new TreeMap<>();
    private final Map<String, FixedWing> fixedWings = new HashMap<>();
    private final Map<String, Helicopter> helicopters = new HashMap<>();

    private DataStore() {
    }

    public static DataStore getInstance() {
        return INSTANCE;
    }

    public Map<String, Airport> getAirports() {
        return airports;
    }

    public Map<String, FixedWing> getFixedWings() {
        return fixedWings;
    }

    public Map<String, Helicopter> getHelicopters() {
        return helicopters;
    }

    public void clear() {
        airports.clear();
        fixedWings.clear();
        helicopters.clear();
    }
}
