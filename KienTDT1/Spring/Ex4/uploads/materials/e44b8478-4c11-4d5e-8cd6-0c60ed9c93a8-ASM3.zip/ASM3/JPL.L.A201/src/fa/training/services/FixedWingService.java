package fa.training.services;

import fa.training.entities.Airport;
import fa.training.entities.FixedWing;
import fa.training.entities.PlaneType;
import fa.training.utils.DataStore;
import fa.training.utils.Validation;

import java.util.Map;

public class FixedWingService {

    private DataStore store = DataStore.getInstance();

    public void createFixedWing(String id,
                                String model,
                                PlaneType type,
                                double cruiseSpeed,
                                double emptyWeight,
                                double maxTakeoff,
                                double runwaySize) {

        if (!Validation.checkFixedWingID(id)) {
            System.out.println("Invalid fixed wing id!");
            return;
        }

        if (!Validation.isFixedWingIdUnique(id)) {
            System.out.println("Fixed wing id exists!");
            return;
        }

        if (!Validation.checkModel(model)) {
            System.out.println("Invalid model!");
            return;
        }

        FixedWing fw = new FixedWing(
                id,
                Validation.trimModel(model),
                cruiseSpeed,
                emptyWeight,
                maxTakeoff,
                type,
                runwaySize
        );

        store.getFixedWings().put(id, fw);

        System.out.println("Create fixed wing success!");
    }

    public void addToAirport(String airportId,
                             String fixedWingId) {

        Airport airport =
                store.getAirports().get(airportId);

        if (airport == null) {
            System.out.println("Airport not found!");
            return;
        }

        FixedWing fw =
                store.getFixedWings().get(fixedWingId);

        if (fw == null) {
            System.out.println("Fixed wing not found!");
            return;
        }

        if (fw.getMinNeededRunwaySize()
                > airport.getRunwaySize()) {

            System.out.println("Runway not enough!");
            return;
        }

        airport.getFixedWingIDs().add(fixedWingId);

        System.out.println("Add fixed wing success!");
    }

    public void displayAllFixedWing() {

        Map<String, FixedWing> list =
                store.getFixedWings();

        if (list.isEmpty()) {
            System.out.println("No fixed wing found!");
            return;
        }

        System.out.println("----- FIXED WING LIST -----");

        for (FixedWing fw : list.values()) {
            System.out.println(fw);
        }
    }
}