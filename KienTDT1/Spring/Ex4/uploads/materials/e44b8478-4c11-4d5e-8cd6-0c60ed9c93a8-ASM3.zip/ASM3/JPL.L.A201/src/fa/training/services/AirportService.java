package fa.training.services;

import fa.training.entities.Airport;
import fa.training.utils.DataStore;
import fa.training.utils.Validation;

import java.util.Map;

public class AirportService {

    private DataStore store = DataStore.getInstance();

    public void createAirport(String id,
                              String name,
                              double runwaySize,
                              int fixedParking,
                              int helicopterParking) {

        if (!Validation.checkAirportID(id)) {
            System.out.println("Invalid airport id!");
            return;
        }

        if (!Validation.isAirportIdUnique(id)) {
            System.out.println("Airport id already exists!");
            return;
        }

        if (!Validation.checkModel(name)) {
            System.out.println("Invalid airport name!");
            return;
        }

        if (runwaySize <= 0) {
            System.out.println("Runway size must > 0");
            return;
        }

        Airport airport = new Airport(
                id,
                Validation.trimModel(name),
                runwaySize,
                fixedParking,
                helicopterParking
        );

        store.getAirports().put(id, airport);

        System.out.println("Create airport success!");
    }

    public void displayAllAirports() {

        Map<String, Airport> airports =
                store.getAirports();

        if (airports.isEmpty()) {
            System.out.println("No airport found!");
            return;
        }

        System.out.println("----- AIRPORT LIST -----");

        for (Airport airport : airports.values()) {
            System.out.println(airport);
        }
    }

    public Airport findAirportById(String id) {

        return store.getAirports().get(id);
    }
}