package fa.training.entities;

import java.util.ArrayList;
import java.util.List;

public class Airport {

    private String id;
    private String name;
    private double runwaySize;
    private int maxFixedWingParkingPlace;
    private int maxRotatedWingParkingPlace;
    private List<String> fixedWingIDs;
    private List<String> helicopterIDs;

    public Airport() {
        fixedWingIDs = new ArrayList<>();
        helicopterIDs = new ArrayList<>();
    }

    public Airport(String id, String name, double runwaySize,
                   int maxFixedWingParkingPlace, int maxRotatedWingParkingPlace) {
        this.id = id;
        this.name = name;
        this.runwaySize = runwaySize;
        this.maxFixedWingParkingPlace = maxFixedWingParkingPlace;
        this.maxRotatedWingParkingPlace = maxRotatedWingParkingPlace;
        fixedWingIDs = new ArrayList<>();
        helicopterIDs = new ArrayList<>();
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getRunwaySize() {
        return runwaySize;
    }

    public void setRunwaySize(double runwaySize) {
        this.runwaySize = runwaySize;
    }

    public int getMaxFixedWingParkingPlace() {
        return maxFixedWingParkingPlace;
    }

    public int getMaxRotatedWingParkingPlace() {
        return maxRotatedWingParkingPlace;
    }

    public List<String> getFixedWingIDs() {
        return fixedWingIDs;
    }

    public List<String> getHelicopterIDs() {
        return helicopterIDs;
    }

    public boolean hasFixedWingCapacity() {
        return fixedWingIDs.size() < maxFixedWingParkingPlace;
    }

    public boolean hasHelicopterCapacity() {
        return helicopterIDs.size() < maxRotatedWingParkingPlace;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder(160);
        sb.append("Airport{id='").append(id)
                .append("', name='").append(name)
                .append("', runwaySize=").append(runwaySize)
                .append(", maxFW=").append(maxFixedWingParkingPlace)
                .append(", parkedFW=").append(fixedWingIDs)
                .append(", maxRW=").append(maxRotatedWingParkingPlace)
                .append(", parkedRW=").append(helicopterIDs)
                .append('}');
        return sb.toString();
    }
}
