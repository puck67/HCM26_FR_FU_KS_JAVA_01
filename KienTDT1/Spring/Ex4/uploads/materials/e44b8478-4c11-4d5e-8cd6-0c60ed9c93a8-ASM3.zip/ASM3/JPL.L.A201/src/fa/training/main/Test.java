package fa.training.main;

import fa.training.entities.PlaneType;
import fa.training.services.AirportService;
import fa.training.services.FixedWingService;
import fa.training.services.HelicopterService;

import java.util.Scanner;

public class Test {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        AirportService airportService =
                new AirportService();

        FixedWingService fixedWingService =
                new FixedWingService();

        HelicopterService helicopterService =
                new HelicopterService();

        while (true) {

            System.out.println("\n===== MENU =====");
            System.out.println("1. Create airport");
            System.out.println("2. Create fixed wing");
            System.out.println("3. Create helicopter");
            System.out.println("4. Show airports");
            System.out.println("5. Show fixed wings");
            System.out.println("6. Show helicopters");
            System.out.println("7. Exit");

            System.out.print("Choose: ");

            int choice =
                    Integer.parseInt(sc.nextLine());

            switch (choice) {

                case 1:

                    System.out.print("Enter id: ");
                    String airportId = sc.nextLine();

                    System.out.print("Enter name: ");
                    String airportName = sc.nextLine();

                    System.out.print("Enter runway size: ");
                    double runway =
                            Double.parseDouble(sc.nextLine());

                    System.out.print("Enter fixed parking: ");
                    int fixed =
                            Integer.parseInt(sc.nextLine());

                    System.out.print("Enter helicopter parking: ");
                    int heli =
                            Integer.parseInt(sc.nextLine());

                    airportService.createAirport(
                            airportId,
                            airportName,
                            runway,
                            fixed,
                            heli
                    );

                    break;

                case 2:

                    System.out.print("Enter id: ");
                    String fwId = sc.nextLine();

                    System.out.print("Enter model: ");
                    String fwModel = sc.nextLine();

                    System.out.print("Enter type (1-CAG 2-LGR 3-PRV): ");
                    int type =
                            Integer.parseInt(sc.nextLine());

                    fixedWingService.createFixedWing(
                            fwId,
                            fwModel,
                            PlaneType.fromCode(type),
                            500,
                            2000,
                            4000,
                            3000
                    );

                    break;

                case 3:

                    System.out.print("Enter id: ");
                    String heliId = sc.nextLine();

                    System.out.print("Enter model: ");
                    String heliModel = sc.nextLine();

                    helicopterService.createHelicopter(
                            heliId,
                            heliModel,
                            300,
                            1000,
                            1200,
                            500
                    );

                    break;

                case 4:

                    airportService.displayAllAirports();

                    break;

                case 5:

                    fixedWingService.displayAllFixedWing();

                    break;

                case 6:

                    helicopterService.displayAllHelicopter();

                    break;

                case 7:

                    System.exit(0);
            }
        }
    }
}