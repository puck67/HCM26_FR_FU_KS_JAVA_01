package fa.training.entities;

public class FixedWing extends Airplane {

    private PlaneType planeType;
    private double minNeededRunwaySize;

    public FixedWing() {
    }

    public FixedWing(String id, String model, double cruiseSpeed,
                     double emptyWeight, double maxTakeoffWeight,
                     PlaneType planeType, double minNeededRunwaySize) {
        super(id, model, cruiseSpeed, emptyWeight, maxTakeoffWeight);
        this.planeType = planeType;
        this.minNeededRunwaySize = minNeededRunwaySize;
    }

    @Override
    public FlyMethod flyMethod() {
        return FlyMethod.FIXED_WING;
    }

    public PlaneType getPlaneType() {
        return planeType;
    }

    public void setPlaneType(PlaneType planeType) {
        this.planeType = planeType;
    }

    public double getMinNeededRunwaySize() {
        return minNeededRunwaySize;
    }

    public void setMinNeededRunwaySize(double minNeededRunwaySize) {
        this.minNeededRunwaySize = minNeededRunwaySize;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append("FixedWing{id='").append(id)
                .append("', model='").append(model)
                .append("', type=").append(planeType)
                .append(", cruiseSpeed=").append(cruiseSpeed)
                .append(", emptyWeight=").append(emptyWeight)
                .append(", maxTakeoffWeight=").append(maxTakeoffWeight)
                .append(", minRunway=").append(minNeededRunwaySize)
                .append('}');
        return sb.toString();
    }
}
